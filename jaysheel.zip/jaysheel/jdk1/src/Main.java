import java.util.Scanner;

import java.io.*;
public class Main {
	
	static String ac;
	static String cot;
	static String cable;
	static String wifi;
	static String laundry;
	static String date;
	static int charge=0;
	
	public static void book(String ac,String cot, String cable,
			String wifi,String laundry,String date)  
			
				{
						System.out.println("The total charge is Rs."+ charge+".");
						System.out.println("The services chosen are");
						System.out.print(cot+" cot"+" " );
						if(ac.equals("AC"))
						{
							System.out.println(ac+" room");
						}
						else{
							System.out.println("non-AC room");
						}
						if(cable.equals("C"))
						{
							System.out.println("Cable connection enabled");
						}
						else{
							System.out.println("Cable connection disabled");
						}
						if(wifi.equals("W"))
						{
							System.out.println("Wi-Fi enabled");
						}
						else{
							System.out.println("Wi-Fi disabled");
						}
						if(laundry.equals("L"))
						{
							System.out.println("with laundry service");
						}
						else
						{
							System.out.println("without laundry service");
						}
						
						System.out.println("and the Date of Booking is "+date);
						System.out.println();
						
					}
					public static void main(String[] args)throws Exception {
						String res;
						BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
						System.out.println("Booking:");
						System.out.println();
						do{
							
						
						System.out.println("Please choose the services required.");
						System.out.println("AC/non-AC(AC/nAC)");
						ac=br.readLine();
						if(ac.equals("AC"))
						{
							charge=charge+1000;
						}
						else{
							charge=charge+750;
						}
						System.out.println("Cot(Single/Double)");
						cot=br.readLine();
						if(cot.equals("Double"))
						{
							charge=charge+350;
						}
						System.out.println("With cable connection/without cable connection(C/nC)");
						cable=br.readLine();
						if(cable.equals("C"))
						{
							charge=charge+50;
						}
						System.out.println("Wi-Fi needed or not(W/nW)");
						wifi=br.readLine();
						if(wifi.equals("W")){
							charge=charge+200;
						}
						System.out.println("Laundry service needed or not(L/nL)");
						laundry=br.readLine();
						if(laundry.equals("L")){
							charge=charge+100;
						}
						System.out.println("Enter the Date of Booking");
						System.out.println();
						date=br.readLine();
						
						
						Main m=new Main();
						m.book(ac,cot,cable,wifi,laundry,date);
						System.out.println("Do you want to proceed?(yes/no)");
						System.out.println();
						res=br.readLine();
						charge=0;
						}while(res.equals("no"));
						
							System.out.println("Thank you for booking. Your room number is 1.");	

					}

				}   
