import java.util.HashMap;
import java.util.Iterator;



public class UserMainCode {
public static float maps(HashMap<Integer,Float>hm)
{int k, count=0;
		float sum=0.0f;
	Iterator<Integer> itr=hm.keySet().iterator();
	while(itr.hasNext())
	{
		k=itr.next();
		if(k%2==0){
		  sum=sum+hm.get(k);
		  count ++;
		  
		}
	}
	float avg=sum/count;
	return avg;
}
}
