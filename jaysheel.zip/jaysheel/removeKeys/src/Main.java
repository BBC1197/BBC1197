import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;


public class Main {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		
		UserMainCode um=new UserMainCode();
		HashMap<Integer,Float> hm=new HashMap<Integer,Float>();
		for(int i=0;i<n;i++){
			int key=sc.nextInt();
			float value=sc.nextFloat();
		
			hm.put(key, value);
		
		}
		System.out.println(String.format("%.2f", um.maps(hm)));
		
	}
}
