import java.text.SimpleDateFormat;
import java.util.Date;


public class UserMainCode {
	public String disp(String s)
	{
		SimpleDateFormat sdf=new SimpleDateFormat("hh:mm a");
		sdf.setLenient(false);
		try
		{
			Date d=sdf.parse(s);
			return "Valid";
		}
		catch(Exception e)
		{
			return "Invalid";
		}
	}

}
