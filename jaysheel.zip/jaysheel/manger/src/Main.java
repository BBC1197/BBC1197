import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Scanner;


public class Main {
public static void main(String args[])
{
	int id,sal;
	String name;
	HashMap<Integer,String> hm1=new HashMap<Integer,String>();
	HashMap<Integer,Integer> hm2=new HashMap<Integer,Integer>();
	
	Scanner s=new Scanner(System.in);
	int n=Integer.parseInt(s.next());
	for(int i=0;i<n;i++)
	{
		 id=s.nextInt();
		 name=s.nextLine();
		 sal=s.nextInt();
		
		hm1.put(id, name);
		hm2.put(id, sal);
	}		
	HashMap<Integer,Integer> hm3=new HashMap<Integer,Integer>();
	Iterator<Integer>itr=hm1.keySet().iterator();
	Iterator<Integer>itr1=hm2.values().iterator();
	while(itr.hasNext())
	{
		int a=itr.next();
		String str=hm1.get(a);
		int b=itr1.next();
		if(str.equals("manager"))
		{
			hm3.put(a, b+5000);
		}
	}
	Iterator<Integer>itr3=hm3.keySet().iterator();
	for(int i=0;i<hm3.size();i++)
	{
		int k=itr3.next();
		int l=hm3.get(k);
		System.out.println(k);
		System.out.println(l);
	}
}
} 