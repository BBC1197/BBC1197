
import java.util.ArrayList;
import java.util.Iterator;
public class Hotel{
String name, hotelId, address;
static String reserved=""; 
//String roomId, roomType, roomNumber, roomCapacity, roomAc, roomWifi, roomCabel, roomLaundry;
//ArrayList roomList=new ArrayList();
ArrayList<Room> robj = new ArrayList<Room>();
ArrayList<Reservation> resobj = new ArrayList<Reservation>();

public void addRoom(Room rom)
{
	robj.add(rom);
	
}
public void addreservation(Reservation res)
{
	resobj.add(res);
}
public void display()
{
	Iterator itr=robj.iterator();
	while(itr.hasNext()==true)
	{
		Room st=(Room)itr.next();
		System.out.println();
	    System.out.println();
		System.out.println("Room Number :"+st.roomNumber);
		System.out.println("Room Type :"+st.roomType);
		System.out.println("Services Available:");
        if(st.roomAc.equals("true"))
        {
        	System.out.println("AC");
        }
        if(st.roomWifi.equals("true"))
        {
        	System.out.println("Wi-Fi");
        }
        if(st.roomCabel.equals("true"))
        {
        	System.out.println("Cable Connection");
        }
        if(st.roomLaundry.equals("true"))
        {
        	System.out.println("Laundry");
        }
       
	}
}
public boolean Availability(String type,String cap,String ac,String wifi,String cab,String lan)
{
	Boolean b=false;
	int count;
	Iterator itr=robj.iterator();
	int itrcount=0;
	while(itr.hasNext()==true)
	{   count=0;
		Room st=(Room)itr.next();
		if(st.roomType.equals(type))
		{
			count=count+1;
		}
		if(st.roomCapacity.equals(cap))
		{
			count=count+1;
		}
		if(st.roomAc.equals(ac))
		{
			count=count+1;
		}
		if(st.roomWifi.equals(wifi))
		{
			count=count+1;
		}
		if(st.roomCabel.equals(cab))
		{
			count=count+1;
		}
		if(st.roomLaundry.equals(lan))
		{
			count=count+1;
		}
		if(count==6)
		{
			b=true;
			this.reserved=st.roomNumber;
			itr.remove();
			break;
		}
		
	}
	return b;
}
public void displayres()
{
	Iterator itrr=resobj.iterator();
	while(itrr.hasNext()==true)
	{
		Reservation str=(Reservation)itrr.next();
		System.out.println(str.customer+" - "+str.room+" - "+str.bookingDate+" - "+str.checkInDate+" - "+str.checkOutDate);
	}
}
}   

