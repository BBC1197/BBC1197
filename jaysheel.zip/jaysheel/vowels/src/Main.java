import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;


public class Main {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	ArrayList<String> al=new ArrayList<String>();
	for(int i=0;i<n;i++){
		al.add(sc.next());
	}
	UserMainCode um=new UserMainCode();
	System.out.println(um.display(al));
	
//	Iterator<String> it=al.iterator();
//	while(it.hasNext())
//	{
//		String st=it.next();
//		System.out.println(it.next());
//	}

}
}
 