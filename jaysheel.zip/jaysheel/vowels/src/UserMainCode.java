import java.util.ArrayList;
import java.util.Iterator;


public class UserMainCode {
public static String display(ArrayList<String>al)
{
	ArrayList<String> a=new ArrayList<String>();
	Iterator<String> itr=al.iterator();
	while(itr.hasNext())
	{
		String str=itr.next();
		if(str.matches("[a||e||i||o||u||A||E||I||O||U]{1}.*[a||e||i||o||u||A||E||I||O||U]{1}"))
		{
			a.add(str);
		}
	}
	Iterator<String>itr1 =a.iterator();
	while(itr1.hasNext())
	{
		itr1.next().toString();
	}
	//return null;
	return a.toString();
	
	
	
}
}
