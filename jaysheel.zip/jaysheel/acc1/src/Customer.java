
public class Customer {
         String fname,lname,contactNumber,email,proofType,proofId;
         
         public void registerCustomer(String fname,String lname,String contactNumber,String email, String proofType, String proofId){
        	 this.fname=fname;
        	 this.lname=lname;
        	 this.contactNumber=contactNumber;
        	 this.email=email;
        	 this.proofType=proofType;
        	 this.proofId=proofId;     			 
	}
         public void display()
         {
        	 System.out.println("The customer details are as follows");
        	 System.out.println("The customer details are:");
        	 System.out.println("First Name : "+this.fname);
        	 System.out.println("Last Name : "+this.lname);
        	 System.out.println("COntact Number : "+this.contactNumber);
        	 System.out.println("E-Mail : "+this.email);
        	 System.out.println("Proof Type : "+this.proofType);
        	 System.out.println("Proof ID : "+this.proofId);
        	 
         }
         public void UpdateEmail(String mail)
         {
        	 this.email=mail;
        	 System.out.println("Email updated.");
         }

} 
