import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;


public class Main {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		//String s2=sc.next();
		//int b=a;
		HashMap<Integer,String> hm=new HashMap<Integer,String>();
		HashMap<Integer,String> hm1=new HashMap<Integer,String>();
		for(int i=0;i<5;i++){
			
			hm.put(sc.nextInt(), sc.next());
			//hm1.put(b, s2);
		}
		for(int i=0;i<5;i++)
		{
			hm1.put(sc.nextInt(), sc.next());
		}
		int s=sc.nextInt();
		for(Integer key:hm.keySet()){
			if(s==key)
			{
				System.out.println(key+" "+hm.get(key)+" "+hm1.get(key));
			}
		}
		
		
	}

}
