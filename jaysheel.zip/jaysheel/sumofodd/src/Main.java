import java.util.HashMap;
import java.util.Scanner;


public class Main {
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		HashMap<Integer,Float> hm=new HashMap<Integer,Float>();
		int n=sc.nextInt();
		for(int i=0;i<n;i++){
			hm.put(sc.nextInt(), sc.nextFloat());
			
		}
		
		System.out.println(UserMainCode.result(hm));
	}

}
