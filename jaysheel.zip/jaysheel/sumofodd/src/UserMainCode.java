import java.util.HashMap;
import java.util.Iterator;


public class UserMainCode {
	
public static float result(HashMap<Integer,Float>hm)
{ float sum=0;
int count=0;

	Iterator<Integer> itr=hm.keySet().iterator();
	while(itr.hasNext())
	{
		int k=itr.next();
		if(k%2==0)
		{
			sum=sum+hm.get(k);
			count++;
		}
		
	}
	float res=sum/count;
	return res;
	
}

}

