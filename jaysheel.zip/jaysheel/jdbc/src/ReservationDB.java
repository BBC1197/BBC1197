
import java.sql.Connection; 

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class ReservationDB {
	Connection con=connectionUtil.connectToMysql();
	PreparedStatement st=null;	
	
	public void addReservation() throws SQLException
	{
		 
		String str="insert into reservation(roomID , custID , checkIn  , checkOut , booking)"
				+ " values(?,?,?)";
		st=con.prepareStatement(str);
		
		// hotelID , roomID , roomType , roomNumber , roomCapacity , roomAc , roomWifi , roomCabel , roomLaundry ,
		
		st.setInt(1,Main.ID);
		st.setInt(2, Main.cusID);
		st.setString(3, Main.cd);
		st.setString(4,Main.cod);
		st.setString(5, Main.bd);
	
		st.executeUpdate();
		
	//	System.out.println("Succesfully inserted Reserv");
	}
	
	public void displayAllRoom() throws SQLException
	{
		String str="select * from reservation";
		
		st=con.prepareStatement(str);
		
		ResultSet rs=st.executeQuery(str);
		
		while(rs.next())
		{
			
			System.out.println("The reservation details are as follows:\n");
			System.out.println(rs.getInt(4)  );
			System.out.println("Room Type :" + rs.getString(3));
			System.out.println("Services Available:");
			
			
				
	}
}
}  
