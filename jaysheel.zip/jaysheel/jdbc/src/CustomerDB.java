
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class CustomerDB {
	Connection con=connectionUtil.connectToMysql();
	PreparedStatement st=null;	
	
	public void addCustomer() throws SQLException
	{
		 
		String str="insert into customer(custID , firstname , lastname , contactno , email , prooftype , proofid )"
				+ " values(?,?,?,?,?,?,?)";
		st=con.prepareStatement(str);
		
		st.setInt(1,Main.cusID);
		st.setString(2, Main.cusname);
		st.setString(3, Main.cuslname);
		st.setInt(4,Main.cuscontact);
		st.setString(5, Main.cusmail);
		st.setString(6, Main.cusprooftype);
		st.setString(7,Main.cusproof);
	
		st.executeUpdate();
		
	//	System.out.println("Succesfully inserted Customer");
	}
	
	public void displayCustomers() throws SQLException
	{
		String str="select * from customer";
		
		st=con.prepareStatement(str);
		
		ResultSet rs=st.executeQuery(str);
		
		while(rs.next())
		{
			System.out.println("\nThe customer details are as follows\nThe customer details are:");
			System.out.println("First Name : " + rs.getString(2));
			System.out.println("Last  Name : " + rs.getString(3));
			System.out.println("Contact Number : " + rs.getString(4));
			System.out.println("E-Mail :" + rs.getString(5));
			System.out.println("Proof Type :" + rs.getString(6));
			System.out.println("Proof ID :" + rs.getString(7));
			
			if(rs.getInt(6) == 1){
				System.out.println("AC");
			}
			
			if(rs.getInt(7) == 1){
				System.out.println("Wi-Fi");
			}
			
			if(rs.getInt(8) == 1){
				System.out.println("Cable Connection");
			}
			
			if(rs.getInt(9) == 1){
				System.out.println("Laundry");
			}
		}
				
	}
}  