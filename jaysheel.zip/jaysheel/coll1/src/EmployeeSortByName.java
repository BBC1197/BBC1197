import java.util.Comparator;
 
// sort by name
class EmployeeSortByName implements Comparator<Customer>  {
    public int compare(Customer emp1,Customer emp2) {
        return emp1.fn.compareTo(emp2.fn);
    }
}  