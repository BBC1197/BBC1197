import java.util.*;  
import java.io.*;  
public class Main{  
public static void main(String args[]){  
ArrayList<Student> al=new ArrayList<Student>();  
Scanner scan=new Scanner(System.in);
int n=scan.nextInt();
for(int i=0;i<n;i++){
al.add(new Student(scan.nextInt(),scan.nextLine(),scan.nextInt()));  
} 
  
Collections.sort(al);  
for(Student st:al){  
System.out.println(st.rollno+" "+st.name+" "+st.age);  
}  
}  
}  