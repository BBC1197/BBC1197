import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Calendar;


public class UserMainCode {
	int res;
public void month(String s1,String s2){
	if(s1.matches("[0-9]{2}[-]{1}[0-9]{2}[-]{1}[0-9]{4}")&& s2.matches("[0-9]{2}[-]{1}[0-9]{2}[-]{1}[0-9]{4}"))
	{
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		SimpleDateFormat sdf1=new SimpleDateFormat("dd-MM-yyyy");
		sdf.setLenient(false);
		sdf1.setLenient(false);
		try{
			Date d1=sdf.parse(s1);
			Date d2=sdf1.parse(s2);
			Calendar c= Calendar.getInstance();
			c.setTime(d1);
			int a=c.get(Calendar.MONTH);
			int b=c.get(Calendar.YEAR);
			c.setTime(d2);
			int a1=c.get(Calendar.MONTH);
			int b1=c.get(Calendar.YEAR);
			if(b>=b1){
				res=Math.abs((b1-b)*12+Math.abs(a-a1));
				
			}
			
			System.out.println(res);
			
		}
		catch(Exception e)
		{
			System.out.println("Invalid");
		}
	}
	else{
		System.out.println("Invalid");
	}
}
}