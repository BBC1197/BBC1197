import java.util.Scanner;


public class Main {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		String str=scan.next();
		int n=scan.nextInt();
		StringBuffer sb=new StringBuffer();
	    int k=str.length();
	    if(k>=2*n){
	    sb.append(str.substring(0, n));
	    sb.append(str.substring(k-n));
	    System.out.println(sb);
	    }
	}

}
