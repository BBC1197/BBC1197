
import java.util.*;


public class Main6 {
public static void main(String args[])
{
	Scanner s=new Scanner(System.in);
	int n=s.nextInt();
	HashMap<Integer,Integer> hm=new HashMap<Integer,Integer>();
	ArrayList<Integer> arr=new ArrayList<Integer>();
	int temp=0;
	for(int i=0;i<n;i++)
	{
		hm.put(s.nextInt(),s.nextInt());
		
	}
	
	for(Integer key:hm.keySet())
	{
		arr.add(hm.get(key));
		System.out.println(hm.get(key));
	}
	
	Collections.sort(arr);
	for(int i=0;i<arr.size()-3;i++)
	{
		temp=temp+arr.get(i);
		System.out.println(temp);
	}
	
	System.out.println(temp);
}
} 
