import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;


public class Main {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		int n=scan.nextInt();
		ArrayList<Integer> al=new ArrayList<Integer>();
		for(int i=0;i<n;i++)
		{
			al.add(scan.nextInt());
		}
		Iterator<Integer> itr=al.iterator();
		for(int i=0;i<n;i=i+3)
		{
		int k=al.get(i);
		
	
		}
al.getva
		}

}
