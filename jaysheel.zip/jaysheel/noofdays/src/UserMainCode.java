import java.util.Calendar;
import java.util.GregorianCalendar;


public class UserMainCode {
	public static int disp(int num,int n)
	{ int res=0;
		Calendar cal=Calendar.getInstance();
		cal.set(Calendar.YEAR, num);
		cal.set(Calendar.MONTH,n);
		GregorianCalendar gc=new GregorianCalendar();
		boolean b= gc.isLeapYear(num);
		if(b)
		{
			if(n==1)
			{
				 res=29;
			}
			
		}
		else{
			
			 res=cal.getActualMaximum(Calendar.DAY_OF_MONTH);
		}
			
		return res;
		
	}

}
