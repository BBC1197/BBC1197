package demo1;
 public class A{
	 void method()
 }