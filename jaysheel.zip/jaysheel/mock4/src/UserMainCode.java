public class UserMainCode {
	static String processString(String a)
	{
		String b="";
		int count=0;
		char c[]=a.toCharArray();
		for(int i=0;i<a.length();i++)
		{
			if(c[i]=='x')
			{
				count=count+1;
			}
			else
			{
				b=b+c[i];
			}
		}
		while(count !=0)
		{
			b=b+"x";
			count=count-1;
		}
		return b;
	}
} 