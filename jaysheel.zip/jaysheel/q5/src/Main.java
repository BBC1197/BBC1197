
import java.util.*;
import java.io.*;
public class Main {
		static BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			
			static ArrayList<Integer> customerIdList = new ArrayList<Integer>();
			static ArrayList<Integer> roomNumberList = new ArrayList<Integer>();
			static ArrayList<String> bookingDateList = new ArrayList<String>(); 
			
			 
		static void viewBookings(ArrayList<Integer> customerIdList,ArrayList<Integer> roomNumberList) throws IOException{
				 
System.out.println("\nView all bookings:");
				
				System.out.println("\nEnter the start date");
				String start = br.readLine();
				bookingDateList.add(start);

				System.out.println("Enter the end date");
				String end = br.readLine();
				bookingDateList.add(end);
				 

				System.out.println("The bookings made from "+start +  " to " + end +" are");
				System.out.format("%-10s%-10s\n","Room number ","Customer ID"); 
				for(int j =0; j<roomNumberList.size(); j ++){
				System.out.format("%d%12d",roomNumberList.get(j),customerIdList.get(j));
				System.out.println(); 
		}
			}   

static void book(int Charges, String Ac, String Cot, String Cable, String Wifi, String Laundry) {
				System.out.println("\nThe total charge is Rs." + Charges + ".");

				System.out.println("The services chosen are\n" + Cot + " cot " + Ac + " room");
				
				if(Cable.equals("C")){
					System.out.println("Cable connection enabled");
				}else{
					System.out.println("Cable connection disabled");
				} 
if(Wifi.equals("W")){
					System.out.println("Wi-Fi enabled");
				}else{
					System.out.println("Wi-Fi disabled");
				} 
		if(Laundry.equals("L")){
					System.out.println("with laundry service");
				}else{
					System.out.println("without laundry service" );
				}
					

			} 

public static void main(String[] args) throws IOException {
						// TODO Auto-generated method stub
						
						String reg;
						
						int i = 0, roomNo = 0;
						 
do{
						
						System.out.println("\nRegistration");
						System.out.println();
						System.out.println("Enter your name");
						String name=br.readLine();
						System.out.println("Enter your address");
						String address=br.readLine();
						System.out.println("Contact Number");
						String contactNumber=br.readLine();
						System.out.println("E-Mail ID");
						String email=br.readLine();
						System.out.println("Enter proof type"); 
				String proofType=br.readLine();
						System.out.println("Enter proof id");
						String proofID=br.readLine();   
							customerIdList.add(++i);  

System.out.println("\nThank you for registering. Your id is " + i + "."+".");
													
													System.out.println("\nDo you want to book a room (y/n)?");
													String booking = br.readLine();
													if(booking.equals("n")){
														System.out.println("\nThank You");
														customerIdList.remove(i-1);
													}
													else if(booking.equals("y")){
													System.out.println("\nBooking:");
													
													String ac, cot, cable, wifi, laundry, date, proceed;
													 
									int charges = 0;
													    System.out.println("AC/non-AC(AC/nAC)");
														ac = br.readLine();
														if(ac.equals("AC")){
															charges += 1000;
														}
														else if(ac.equals("nAC")){
															charges += 750;
															ac = "non-AC";
														}

														System.out.println("Cot(Single/Double)");
														cot = br.readLine();
														if(cot.equals("Double")){
															charges += 350;
														} 


		System.out.println("With cable connection/without cable connection(C/nC)");
														cable = br.readLine();
														if(cable.equals("C")){
															charges += 50;
														} 
									System.out.println("Wi-Fi needed or not(W/nW)");
														wifi = br.readLine();
														if(wifi.equals("W")){
															charges += 200;
														}
														System.out.println("Laundry service needed or not(L/nL)");
														laundry = br.readLine();
														if(laundry.equals("L")){
															charges += 100;
														}   
System.out.println("\nEnter the date of booking");
	date = br.readLine();
																						
	book(charges, ac, cot, cable, wifi, laundry);
																						
	System.out.println("\nDo you want to proceed?(yes/no)");
																						
	proceed = br.readLine();
																						
	if(proceed.equals("yes")){
	roomNumberList.add(++roomNo); 
	System.out.println("\nThank you for booking. Your room number is " + roomNo  +".");
																						}
																						
																					}   

System.out.println("\nDo you want to continue registration?(yes/no)");
																					
																					reg = br.readLine();
																					
																					}while(reg.equals("yes"));
																					
																					if(reg.equals("no")){
																						viewBookings(customerIdList, roomNumberList );
																					}
																			} 

																	}   


													