import java.util.Scanner;


public class Main {
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		int str1=sc.nextInt();
		int str2=sc.nextInt();
		UserMainCode um=new UserMainCode();
		um.month(str1,str2);
	}

}
