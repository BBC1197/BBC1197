import java.util.Date;
import java.util.GregorianCalendar;
import java.text.SimpleDateFormat;
import java.util.Calendar;


public class UserMainCode {
	int res,k;
public void month(int  s1,int s2){
	
		SimpleDateFormat sdf=new SimpleDateFormat();
		
		//sdf.setLenient(false);
		
					
			Calendar c= Calendar.getInstance();
			c.set(Calendar.YEAR,s1);
			c.set(Calendar.MONTH,s2);
			GregorianCalendar g=new GregorianCalendar();
			boolean f=g.isLeapYear(s1);
			if(f||s2!=1 )
			{
				k=c.getActualMaximum(c.DAY_OF_MONTH);
			}
			else{
				k=28;
			
			}
			
			System.out.println(k);
			
		
}
}