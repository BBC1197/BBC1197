public class UserMainCode {
	public static int disp(int num){
		int pal;
		int res=0;
		int rem;
		int j;
		int i;
		boolean f=true;
		while(f)
		{
			i=num+1;
			pal=0;
			j=i;
			while(j!=0){		
				rem=j%10;
				pal=rem+(pal*10);
				j=j/10;
			}	
			if(pal==i){
				res=pal;
				f=false;
			
		}
			else{
				f=true;
			}
		}
		return res;	
	}}