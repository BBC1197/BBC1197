import java.util.Scanner;


public class Main {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		UserMainCode um=new UserMainCode();
		System.out.println(um.disp(n));
		
	}

}
