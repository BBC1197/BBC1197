public class PartyHall extends Hall {
	String amenities, roomType;

	public PartyHall(int roomid, int hours, int rate, int capacity, boolean soundSystem, String roomType,
			String amenities) {
		super(roomid, hours, rate, capacity, soundSystem);
		this.roomType = roomType;
		this.amenities = amenities;
	}

	void display() {
		System.out.println("Party Hall");
		System.out.println("Room ID : " + roomid);
		System.out.println("Capacity : " + capacity);
		System.out.println("Sound System : " + soundSystem);
		System.out.println("Type of Party : " + roomType);
		System.out.println("Amenties : " + amenities);
		System.out.println("Room Rate : " + rate);
		System.out.println();
	}
}