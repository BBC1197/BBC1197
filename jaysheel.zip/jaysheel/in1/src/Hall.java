public class Hall extends Room {
	int capacity;
	boolean soundSystem;

	public Hall(int roomid, int hours, int rate, int capacity, boolean soundSystem) {
		super(roomid, hours, rate);
		this.capacity = capacity;
		this.soundSystem = soundSystem;
	}

	void display() {
	}
}