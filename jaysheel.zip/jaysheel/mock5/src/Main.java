import java.util.*;
public class Main
{
    public static void main(String args[])
    {
        Scanner ob=new Scanner(System.in);
        //System.out.println("Enter the sentence.");
        String s=ob.nextLine();
        UserMainCode ur=new UserMainCode();
        ur.processString(s);
        
    }
}