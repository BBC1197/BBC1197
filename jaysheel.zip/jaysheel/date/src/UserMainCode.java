import java.util.Date;
import java.text.SimpleDateFormat;


public class UserMainCode {
	public void check(String st)
	{
		if(st.matches("[0-9]{2}[-]{1}[0-9]{2}[-]{1}[0-9]{4}"))
		{
			SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
			SimpleDateFormat sdf1=new SimpleDateFormat("MMMM");
			sdf.setLenient(false);
			sdf1.setLenient(false);
			try
			{
				Date d1=sdf.parse(st);
				String d2=sdf1.format(d1);
				System.out.println(d2.toUpperCase());
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else{
			System.out.println("invalid");
		}
		
	}

}
