class raju{
	//int index=1;
	
	static void printNumber(int array[], int index){

		array[index] = index ;

		System.out.println(array[index]);

		printNumber(array, index+1);

		}
public static void main(String[] args) {
	int array[]=new int[101];
	
	try{

		printNumber(array,1);

		}catch(ArrayIndexOutOfBoundsException e){

		}

		}

		

}

