package selenium;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class list_exaple {
	
		public static void main(String[] args) throws IOException {
			
			System.setProperty("webdriver.chrome.driver","D:\\New folder\\chromedriver 2.35\\chromedriver.exe");
			WebDriver driver=new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			driver.get("https://github.com/join");
			List<WebElement> lis =driver.findElements(By.xpath("//input[@type='text']"));
			for(int i=0;i<lis.size();i++)
			{
				if(lis.get(i).isEnabled()){
					
				
			lis.get(i).sendKeys("ram");
			}}

}}
