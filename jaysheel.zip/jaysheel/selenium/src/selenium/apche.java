package selenium;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class apche {
public static void main(String[] args) throws IOException {
	FileInputStream fil=new FileInputStream("D:\\jaysheel\\selenium\\testing.xlsx");
	
	XSSFWorkbook workbook=new XSSFWorkbook(fil);
	XSSFSheet Sheet= workbook.getSheetAt(0);
	int rowcount = Sheet.getLastRowNum();
	System.out.println(rowcount);
	for(int i=0;i<=rowcount;i++)
		{
		XSSFRow row=Sheet.getRow(i);
		XSSFCell cell=row.getCell(0);
		String Username=cell.getStringCellValue();
		XSSFCell cell1=row.getCell(1);
		String password =cell1.getStringCellValue();
		
		System.setProperty("webdriver.chrome.driver","D:\\BRO\\Chrome Drivers\\chromedriver 2.35\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		//driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
driver.get("http://opensource.demo.orangehrmlive.com/");

driver.findElement(By.id("txtUsername")).sendKeys(Username);
driver.findElement(By.id("txtPassword")).sendKeys(password);
driver.findElement(By.id("btnLogin")).click();

	
}
}
}
