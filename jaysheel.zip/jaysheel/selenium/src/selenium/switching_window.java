package selenium;

import java.io.IOException;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class switching_window {
	public static void main(String[] args) throws IOException {
		
		System.setProperty("webdriver.chrome.driver","D:\\New folder\\chromedriver 2.35\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.get("http://toolsqa.wpengine.com/automation-practice-switch-windows/");
		String handle=driver.getWindowHandle();
		System.out.println(handle);
		driver.findElement(By.xpath("//*[@id='content']/p[3]/button")).click();
		Set<String> handles=driver.getWindowHandles();
		System.out.println(handles);
		for(String handle1:driver.getWindowHandles())
		{
			System.out.println(handle1);
			driver.switchTo().window(handle1);
			driver.close();
		}
		driver.quit();
		
		
		}
	}



