package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;



public class select_ex {
	public static void main(String[] args) {
		
		System.setProperty("webdriver.ie.driver","D:\\New folder\\IE Driver\\IEDriverServer_Win32_3.12.0\\IEDriverServer.exe");
		WebDriver driver=new InternetExplorerDriver();
//		driver.manage().window().maximize();
//		driver.get("http://toolsqa.com/automation-practice-form/");
//		WebElement ele=driver.findElement(By.id("continents"));
//		Select sele=new Select(ele);
//		sele.selectByIndex(4);
//		WebElement ele1=driver.findElement(By.id("selenium_commands"));
//	    Select sel1=new Select(ele1);
//	    sel1.selectByIndex(0);
//	    sel1.selectByIndex(1);
//	    sel1.selectByIndex(2);
//	    sel1.selectByIndex(3);
////	    sel1.deselectByIndex(0);
////	    sel1.deselectByIndex(1);
////	    sel1.deselectByIndex(2);
	    driver.manage().window().maximize();
		driver.get("https://jqueryui.com");
		driver.findElement(By.linkText("Droppable")).click();
		driver.switchTo().frame(0);
		WebElement ele=driver.findElement(By.id("draggable"));
		WebElement ele1=driver.findElement(By.id("droppable"));
		Actions act=new Actions(driver);
		act.dragAndDrop(ele, ele1).build().perform();
}
}
