import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


public class UserMainCode {
	public static boolean mdiff(String s1,String s2,int n)
	{ int res=0;
		if(s1.matches("[0-9]{4}[-]{1}[0-9]{2}[-]{1}[0-9]{2}") && s2.matches("[0-9]{4}[-]{1}[0-9]{2}[-]{1}[0-9]{2}"))
		{
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
			sdf.setLenient(false);
			try
			{
				Date d1=sdf.parse(s1);
				Date d2=sdf.parse(s2);
				Calendar cal=Calendar.getInstance();
			    cal.setTime(d1);
			    int m=cal.get(Calendar.MONTH);
			    int y=cal.get(Calendar.YEAR);
			    int d=cal.get(Calendar.DATE);
			    cal.setTime(d2);
			    int m1=cal.get(Calendar.MONTH);
			    int y1=cal.get(Calendar.YEAR);
			    int dd=cal.get(Calendar.DATE);
			    int k=Math.abs(y-y1);
			    if(m>m1)
			    {
			    	k--;
			    }
			    if(m==m1 && d>dd)
			    {
			    	k--;
			    }
			    if(k==n)
			    {
			    	return true;
			    }
			}
			catch(Exception e)
			{
				return false;
			}
		}
		return false;
		
	}

}
