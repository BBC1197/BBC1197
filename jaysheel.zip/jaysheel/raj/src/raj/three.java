package raj;

import org.testng.annotations.Test;

public class three {
	@Test
	public void dinesh()
	{
		System.out.println("third class");
	}

}
