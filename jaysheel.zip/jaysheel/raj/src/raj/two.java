package raj;

import org.testng.annotations.Test;

public class two {
	@Test
	public void srini()
	{
		System.out.println("second class");
	}

}
