package raj;

import org.testng.annotations.Test;

public class one {
	@Test
	public void test()
	{
		System.out.println("first class");
	}

}
