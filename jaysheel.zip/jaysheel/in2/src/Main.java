
import java.io.*;
import java.util.*;


public class Main {
	
	
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static String Hname, Haddress, w, amenities, roomType1, rooms , fname, lname, contactNo ,emailID , proofType;
	static int roomid = 0, roomName, roomType = 0, hallType , capacity = 0, roomNo = 0, proofID;
	static boolean wifi = false , soundSystem  = false , projector = false;
	
	static String  Camenities, CroomType1, Crooms , Cfname, Clname, CcontactNo ,CemailID , CproofType;
	static int Croomid = 0, CroomName, CroomType = 0, ChallType , Ccapacity = 0, CroomNo = 0, CproofID, CroomRate;
	static boolean Cwifi = false , CsoundSystem  = false , Cprojector = false;
	
	
	
	static 	List<Room> roomDetails = new ArrayList<Room>(); 
	
	public static void roomDetails() throws IOException {
		
		Croomid++;
		int sum = 0;
		System.out.println("Enter the Room name");
		System.out.println("1.Hotel Room");
		System.out.println("2.Hall");
		CroomName = Integer.parseInt(br.readLine());
		if (CroomName == 1) {
			int hours = 24;
			Crooms = "Lodge Room";
			System.out.println("Enter the Room Type");
			System.out.println("1.Single");
			System.out.println("2.Double");
			System.out.println("3.Delux");
			CroomType = Integer.parseInt(br.readLine());
			if (CroomType == 1)
				sum = sum + ((1000 * hours) / 24);
			else if (CroomType == 2)
				sum = sum + ((1500 * hours) / 24);
			else
				sum = sum + ((2000 * hours) / 24);
			System.out.println("Wi-Fi Service (true/false):");
			Cwifi = Boolean.parseBoolean(br.readLine());
			
				} else {
							int hours = 1;
							System.out.println("Enter the Hall Type");
							System.out.println("1.Party Hall");
							System.out.println("2.Conference Hall");
							ChallType = Integer.parseInt(br.readLine());
							if (ChallType == 1) {
								Crooms = "Party Hall";
								System.out.println("Enter the Capacity");
								Ccapacity = Integer.parseInt(br.readLine());
								System.out.println("soundSystem Service (true/false):");
								CsoundSystem = Boolean.parseBoolean(br.readLine());
								System.out.println("Enter the Party Name");
								CroomType1 = br.readLine();
								System.out.println("Enter the Amenities Cost");
								Camenities = br.readLine();
								sum = sum + 200 * hours;
							}

							else {
								sum = sum + 250 * hours;
								Crooms = "Conference Hall";
								System.out.println("Enter the Capacity");
								Ccapacity = Integer.parseInt(br.readLine());
								System.out.println("soundSystem Service (true/false):");
								CsoundSystem = Boolean.parseBoolean(br.readLine());
								System.out.println("Wi-Fi Service (true/false):");
								Cwifi = Boolean.parseBoolean(br.readLine());
								System.out.println("projector Service (true/false):");
								Cprojector = Boolean.parseBoolean(br.readLine());
								
							}
						}
					} 
					public static void main(String[] args) throws IOException {
							// TODO Auto-generated method stub
							
							
							System.out.println("Enter the Hotel Details");
							System.out.println("Enter the Hotel name");
							Hname = br.readLine();
							System.out.println("Enter the Hotel Location");
							Haddress = br.readLine();
							do {
								roomid++;
								int sum = 0;
								System.out.println("Enter the Room name");
								System.out.println("1.Hotel Room");
								System.out.println("2.Hall");
								roomName = Integer.parseInt(br.readLine());
								if (roomName == 1) {
									int hours = 24;
									rooms = "Lodge Room";
									System.out.println("Enter the Room Type");
									System.out.println("1.Single");
									System.out.println("2.Double");
									System.out.println("3.Delux");
									roomType = Integer.parseInt(br.readLine());
									if (roomType == 1)
										sum = sum + ((1000 * hours) / 24);
									else if (roomType == 2)
										sum = sum + ((1500 * hours) / 24);
									else
										sum = sum + ((2000 * hours) / 24);
									System.out.println("Need WiFi ??(true/false)");
									wifi = Boolean.parseBoolean(br.readLine());
									roomNo = roomid;
									Room room = new Room(roomid,capacity,roomType,roomNo,sum,roomName,hallType,rooms,wifi,soundSystem,projector);
									roomDetails.add(room);  
			
				} 
		else
		{
									int hours = 1;
									System.out.println("Enter the Hall Type");
									System.out.println("1.Party Hall");
									System.out.println("2.Conference Hall");
									hallType = Integer.parseInt(br.readLine());
									if (hallType == 1) {
										rooms = "Party Hall";
										System.out.println("Enter the Capacity");
										capacity = Integer.parseInt(br.readLine());
										System.out.println("Need soundSystem ??(true/false)");
										soundSystem = Boolean.parseBoolean(br.readLine());
										System.out.println("Enter the Party Name");
										roomType1 = br.readLine();
										System.out.println("Enter the Amenities Cost");
										amenities = br.readLine();
										sum = sum + 200 * hours;
										Room room = new Room(roomid,capacity,roomType,roomNo,sum,roomName,hallType,rooms,wifi,soundSystem,projector);
										roomDetails.add(room);
									} 

									else {
										sum = sum + 250 * hours;
										rooms = "Conference Hall";
										System.out.println("Enter the Capacity");
										capacity = Integer.parseInt(br.readLine());
										System.out.println("Need soundSystem ??(true/false)");
										soundSystem = Boolean.parseBoolean(br.readLine());
										System.out.println("Need WiFi ??(true/false)");
										wifi = Boolean.parseBoolean(br.readLine());
										System.out.println("Need Projector ??(true/false)");
										projector = Boolean.parseBoolean(br.readLine());
										Room room = new Room(roomid,capacity,roomType,roomNo,sum,roomName,hallType,rooms,wifi,soundSystem,projector);
										roomDetails.add(room);
									}
								}
								System.out.println("Do you want to add another room?(y/n)");
								w = br.readLine();
							} while (w.equals("y"));
							
							int cnt = roomDetails.size();
							System.out.println("Hotel Room Details : ");
							for (int i = 0; i < cnt; i++) {
								Room r = roomDetails.get(i);
								r.display();
							} 
				
				System.out.println("Customer Registration:\n");
							System.out.println("Enter the customer details:\nEnter the first name:");
							fname = br.readLine();
							System.out.println("Enter the last name:");
							lname = br.readLine();
							System.out.println("Enter the contact number:");
							contactNo = br.readLine();
							System.out.println("Enter the e-mail id:");
							emailID = br.readLine();
							System.out.println("Enter the proof type:");
							proofType = br.readLine();
							System.out.println("Enter the proof id:");
							proofID = Integer.parseInt(br.readLine());
							System.out.println("Thank you for registering.\nThe customer details are as follows\nThe customer details are:");
							Customer customer = new Customer(fname, lname,contactNo, emailID, proofType, proofID );
							customer.registerCustomer();
							roomDetails();
							
							System.out.println("AVAILABILITY CHECK");
							
							for (int j = 0; j < roomDetails.size(); j++) {
								Room r = roomDetails.get(j);
								if( ( r.roomName == CroomName && (r.hallType == ChallType || (r.roomType == CroomType ) )  )){
									if(r.roomWifi == Cwifi || r.roomProjector == Cprojector || r.roomCapacity == Ccapacity || r.roomSound == CsoundSystem ){
										
										System.out.println("Room Number :" + r.roomNumber);
										CroomRate = r.sum;
										break;
									}
								}
							}
							
								System.out.println("Enter the number of days :");
											int days = Integer.parseInt(br.readLine());
											System.out.println("Enter today's date :"); 
											String startDate = br.readLine();
											System.out.println("Enter check in date :");
											String lastDate = br.readLine();
											System.out.println("Booking Date : " + startDate) ;
											System.out.println("Check in Date : " + lastDate);
											System.out.println("No of Days : " + days);
											System.out.println("Room Rate : " + (CroomRate*days));
											System.out.println("Wifi Charges ( @ 100 per day ) : " + (days*100));
											int vat = ( (days*100 + (CroomRate*days)) * 10)/100  + ((days*100)*10/100 );
											System.out.println("Vat 10 % : " + (vat));
											System.out.println();
											System.out.println("Total : " + ((CroomRate*days)+vat + (days*100) + (days*100)  ));

										}

									}   


			  
