import java.util.Scanner;


public class Main {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	String str=sc.next();
	int sum=0;

	int k=str.length();
	for(int i=0;i<k;i++){
		if(str.charAt(i)>='0'&& str.charAt(i)<='9')
		{
			int s=Integer.parseInt( str.charAt(i)+"");
			sum=sum+s;
			
		}
		
	}
	System.out.println(sum);
}
}
