import java.util.*;
import java.io.*;
public class Main {
static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

			static ArrayList<Integer> bookedRooms = new ArrayList<Integer>();
			
			static void checkStatus(ArrayList<Integer> BookedRooms) throws NumberFormatException, IOException{
				
				System.out.println("Check Status:\nEnter room number"); 
int room = Integer.parseInt(br.readLine());
				
				if(BookedRooms.contains(room)){
					System.out.println("Room number "+ room +" is booked.");
				}
				else{
					System.out.println("Room number "+ room +" is not booked.");
				}
			}   
static void book(int Charges, String Ac, String Cot, String Cable, String Wifi, String Laundry) {
				System.out.println("The total charge is Rs." + Charges + ".");

				System.out.println("The services chosen are\n" + Cot + " cot " + Ac + " room");
				
				if(Cable.equals("C")){
					System.out.println("Cable connection enabled");
				}else{
					System.out.println("Cable connection disabled");
				} 
if(Wifi.equals("W")){
					System.out.println("Wi-Fi enabled");
				}else{
					System.out.println("Wi-Fi disabled");
				}
				
				if(Laundry.equals("L")){
					System.out.println("with laundry service");
				}else{
					System.out.println("without laundry service" );
				}

			}   
public static void main(String[] args) throws IOException{
				// TODO Auto-generated method stub
				
				String ac, cot, cable, wifi, laundry, proceed;
				
				int n,i =0;
				
				do{
					System.out.println("Menu\n1. Book\n2. Check Status\n3. Exit\nEnter your choice");
					
					 n = Integer.parseInt(br.readLine());
					
					if(n==1){
					
					int charges = 0;
					System.out.println("Booking:\nPlease choose the services required.\nAC/non-AC(AC/nAC)");
					ac = br.readLine();
					if(ac.equals("AC")){ 
charges += 1000;
					}
					else if(ac.equals("nAC")){
						charges += 750;
						ac = "non-AC";
					}
					
					System.out.println("Cot(Single/Double)");
					cot = br.readLine();
					if(cot.equals("Double")){
						charges += 350;
					} 
System.out.println("With cable connection/without cable connection(C/nC)");
					cable = br.readLine();
					if(cable.equals("C")){
						charges += 50;
					}
					System.out.println("Wi-Fi needed or not(W/nW)");
					wifi = br.readLine();
					if(wifi.equals("W")){
						charges += 200; 
}
					System.out.println("Laundry service needed or not(L/nL)");
					laundry = br.readLine();
					if(laundry.equals("L")){
						charges += 100;
					} 
		book(charges, ac, cot, cable, wifi, laundry); 
System.out.println("Do you want to proceed?(yes/no)");
					
					proceed = br.readLine();
					
					if(proceed.equals("yes")){
						bookedRooms.add(++i);
						// System.out.println(bookedRooms);
						System.out.println("Thank you for booking. Your room number is " + i  +".");
					}
					
					}
					
					else if(n ==2){
						checkStatus(bookedRooms);
					}
								
				}while(n<3);
				
				
			} 

			}   