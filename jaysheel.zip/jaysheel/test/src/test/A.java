package test;

public class A {
	public static void main(String[] args) {
		System.out.println();
	}
		
	}
//void method()
//{
//	
//}
//public Object clone()
//{
//	return null;
//}
int count()
{
	System.out.println();
	main
	System.out.println();
	if(a%2==0){
		
	}
}
}

