package test;

public class test {
	

		int width;

		int height;

		int length;

		}

		class mainclass {

		public static void main(String args[])

		{

		test obj1 = new test();

		test obj2 = new test();

		obj1.height = 1;

		obj1.length = 2;

		obj1.width = 1;

		obj2 = obj1;

		System.out.println(obj2.height);

		}

		}

