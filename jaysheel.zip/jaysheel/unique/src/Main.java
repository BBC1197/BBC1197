import java.util.Scanner;


public class Main {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int a=sc.nextInt();
	int b=sc.nextInt();
	int c=sc.nextInt();
	int arr[]=new int[100];
	int i=0;
	int count=0;
	if((a!=b&& a!=c)){
		count++;
	}
	
			if(b!=a&&b!=c){
				count++;
			}
			if(c!=a&&c!=b){
		count++;
	}
	System.out.println(count);
	
}
}
