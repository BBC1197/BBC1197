import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;


public class Main {
	public static void main(String args[]) 
	{
		Scanner s=new Scanner(System.in);
		String a=s.next();
		String b=s.next();
		if(a.matches("[0-9]{2}[/]{1}[0-9]{2}[/]{1}[0-9]{4}")&&b.matches("[0-9]{2}[/]{1}[0-9]{2}[/]{1}[0-9]{4}"))
		{
			SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
			sdf.setLenient(false);
			try{
			Date d=sdf.parse(a);
			System.out.println("valid");
			}
			catch(Exception e)
			{
			
			System.out.println("invalid");
			}
			try{
				Date d1=sdf.parse(b);
				System.out.println("valid");
			}
			catch(Exception e)
			{
				System.out.println("invalid");
			}
		}
	}
	} 


