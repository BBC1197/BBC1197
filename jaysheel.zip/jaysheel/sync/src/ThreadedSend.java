public class ThreadedSend extends Thread{
	
	
	private String msg;
    private Thread t;
    Sender  sender;
 
    // Recieves a message object and a string
    // message to be sent
    ThreadedSend(String m,  Sender obj)
    {
        msg = m;
        sender = obj;
    }
     public void run() {
		// TODO Auto-generated method stub
		 
        try
        {
        	
        	
			sender.send(msg);
        	
        }
        catch(Exception e)
        {
            System.out.println("Interrupted");
        }
    }
    


}