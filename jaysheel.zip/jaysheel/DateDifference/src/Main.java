import java.util.Scanner;


public class Main {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String str1=sc.next();
		String str2=sc.next();
		UserMainCode um=new UserMainCode();
		System.out.println(um.display(str1,str2));
	}

}
