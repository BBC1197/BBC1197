import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


public class UserMainCode {
	public static long display(String s1,String s2)
	{String s="";
	long res=0;
		if(s1.matches("[0-9]{2}[/]{1}[0-9]{2}[/]{1}[0-9]{4}") && s2.matches("[0-9]{2}[/]{1}[0-9]{2}[/]{1}[0-9]{4}"))
		{
			SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
			
			//SimpleDateFormat sdf1=new SimpleDateFormat("dd-MM-yyyy");
			sdf.setLenient(false);
			//sdf1.setLenient(false);
		
			try
			{
				Date d1=sdf.parse(s1);
				 
				Date d2=sdf.parse(s2);
				Calendar cal=Calendar.getInstance();
			cal.setTime(d1);
			
			long y=cal.getTimeInMillis();
			cal.setTime(d2);
			long x=cal.getTimeInMillis();
			long diff=Math.abs(x-y);
		res=diff/(1000*24*60*60);
			
			
				
			}
			catch(Exception e)
			{
				System.out.println("invalid");
			}
		}
		else{
			System.out.println("Invalid");
		}
		
		 return res;
		
		
		
	}

}
