package demo;

public class testing {
	public static void main(String args[]){
		int i=20;
		int j=30;
		int k=i++ + --j;
		System.out.println(k);
	}

}
