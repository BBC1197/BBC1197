package demo;

import java.util.Scanner;

public class test {

	public static void main(String[] args) {
		String username="admin";
		String password="admin";
		
		//Scanner scan= new Scanner(System.in);
		String users[]={"abc","pqr","xyz","def"};
      
		
		
		
		
		if(users[0].equals("abc")||users[1].equals("pqr")||users[2].equals("xyz")||users[3].equals("def")){
    	  if(username.equals(password)) {
    		  System.out.println("home page");
    	  }
    	  else{
    		  System.out.println()
    	  }
       }
        	
        
		/*String username="admin";
		String password="admin";
		if(username.equals(password)){
			System.out.println("home page");
		}
		else{
			System.out.println("invalid credentials");
		}*/
	}

}
