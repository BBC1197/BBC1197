import java.util.*;
public class Main {
	
	public static void main(String[]args) {
		int a=4;
		//double b=a/3.0;
		//System.out.println(b);
		System.out.println((int)Math.ceil(a%3 + a/3.0));
	}

}
  