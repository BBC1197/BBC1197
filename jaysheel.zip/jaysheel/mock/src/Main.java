import java.util.Scanner;


public class Main {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		if(UserMainCode.isTopper(num))
			System.out.println("yes");
		else
			System.out.println("no");
		
	}

} 