public class UserMainCode {
public static boolean isTopper(int num){
	int sumo=0;
	int sume=0;
	int rem=0;
	boolean f;
	while(num>0){
		rem=num%10;
		if(rem%2==0){
			sume=sume+rem;
		}else{
			sumo=sumo+rem;
		}
		num=num/10;
	}
	if(sume==sumo){
		f=true;
	}
	else
		f=false;
	return f;
}
}  